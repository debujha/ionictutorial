import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { Address } from 'src/app/models/address.model';
import { AddressService } from 'src/app/services/address/address.service';
import { GlobalService } from 'src/app/services/global/global.service';

@Component({
  selector: 'app-address',
  templateUrl: './address.page.html',
  styleUrls: ['./address.page.scss'],
})
export class AddressPage implements OnInit, OnDestroy {

  isLoading: boolean ;
  addresses: Address[] = [];
  addressesSub: Subscription;
  model = {
    title: 'No Addresses added yet',
    icon: 'location-outline'
  };

  constructor(
    private global: GlobalService,
    private addressService: AddressService) { } // Constructor injection

  ngOnInit() {
   this.addressesSub = this.addressService.addresses.subscribe( address =>
    {
    console.log(address);
    this.addresses = address;
   }
   );
   this.getAddress();
  }
  async getAddress(){
      this.isLoading = true;
      this.global.showLoader();
      setTimeout(async()=>{
        await this.addressService.getAddresses();
        console.log(this.addresses);
        this.isLoading = false;
        this.global.hideLoader();
      },3000);
  }


  ngOnDestroy() {
  }

}
